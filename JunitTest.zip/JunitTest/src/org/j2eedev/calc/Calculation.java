package org.j2eedev.calc;
/*
 * @author Umashankar 
 * http://j2eedev.org
 * Beginer JUnit Tutorial
 * */
public class Calculation {
	public static int add(int a, int b) {
			return a + b;
		}
		public static int sub(int a, int b) {
			return a - b;
		}
	}
